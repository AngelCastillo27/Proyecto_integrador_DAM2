<?php
include 'conexion.php';

$usuario = $_POST['usuario'] ?? '';

if ($usuario === '') {
    echo "USUARIO_INCOMPLETO";
    exit;
}

// 1. Obtener ID del usuario
$resUser = mysqli_query($conexion, "SELECT id FROM usuarios WHERE usuario='$usuario'");
$filaUser = mysqli_fetch_assoc($resUser);
$usuario_id = $filaUser['id'];

// 2. Marcar como CERRADO el último inventario abierto de este usuario
$query = "UPDATE inventarios SET estado='cerrado' 
          WHERE usuario_id='$usuario_id' AND estado='abierto'";

if (mysqli_query($conexion, $query)) {
    echo "INVENTARIO_FINALIZADO_CON_EXITO";
} else {
    echo "ERROR_AL_CERRAR";
}
?>