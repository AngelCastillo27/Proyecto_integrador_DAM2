<?php
// Desactivar reporte de errores HTML para que no rompan la respuesta de Android
error_reporting(0); 
ini_set('display_errors', 0);

include 'conexion.php';

// Capturamos los datos del POST
$usuario = $_POST['usuario'] ?? '';
$departamento = $_POST['departamento'] ?? '';
$productos = $_POST['productos'] ?? '';
$turno = $_POST['turno'] ?? 'M'; // ✅ Captura el turno enviado desde Android

if ($usuario === '' || $departamento === '' || $productos === '') {
    echo "DATOS_INCOMPLETOS";
    exit;
}

// 1. Obtener usuario_id
$resUser = mysqli_query($conexion, "SELECT id FROM usuarios WHERE usuario='$usuario'");
if (!$resUser || mysqli_num_rows($resUser) === 0) {
    echo "USUARIO_NO_EXISTE";
    exit;
}
$filaUser = mysqli_fetch_assoc($resUser);
$usuario_id = $filaUser['id'];

// 2. Buscar o crear inventario
// Solo buscar el inventario que aún está abierto
$resInv = mysqli_query($conexion, "SELECT id FROM inventarios 
    WHERE usuario_id='$usuario_id' AND estado='abierto' 
    ORDER BY id DESC LIMIT 1");

if (!$resInv || mysqli_num_rows($resInv) === 0) {
    // ✅ Se inserta el turno real recibido y se marca como 'abierto'
    mysqli_query($conexion, "INSERT INTO inventarios (usuario_id, turno, fecha_hora, estado) 
                             VALUES ('$usuario_id', '$turno', NOW(), 'abierto')");
    $inventario_id = mysqli_insert_id($conexion);
} else {
    $filaInv = mysqli_fetch_assoc($resInv);
    $inventario_id = $filaInv['id'];
}

if (!$inventario_id) {
    echo "ERROR_ID_INVENTARIO";
    exit;
}

// 3. Borrar productos previos de este departamento en este inventario (para evitar duplicados al actualizar)
mysqli_query($conexion, "DELETE FROM inventario_productos WHERE inventario_id='$inventario_id' AND departamento='$departamento'");

// 4. Insertar nuevos productos
$lista = explode(",", $productos);
foreach ($lista as $p) {
    if (empty(trim($p))) continue;
    $partes = explode(":", $p);
    
    if (count($partes) >= 2) {
        $nombre = mysqli_real_escape_string($conexion, $partes[0]);
        $cantidad = intval($partes[1]);
        mysqli_query($conexion, "INSERT INTO inventario_productos (inventario_id, departamento, nombre, cantidad) 
                                 VALUES ('$inventario_id', '$departamento', '$nombre', '$cantidad')");
    }
}

echo "OK";
?>