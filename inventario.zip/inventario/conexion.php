<?php
$hostname = 'localhost';
$database = 'inventario_db';
$username = 'root';
$password = '';

// Crear la conexión
$conexion = mysqli_connect($hostname, $username, $password, $database);

// Verificar la conexión
if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

// Configurar para que reconozca tildes y eñes
mysqli_set_charset($conexion, "utf8");
?>