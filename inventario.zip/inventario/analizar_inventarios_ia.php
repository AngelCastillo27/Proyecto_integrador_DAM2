<?php
include 'conexion.php';

// 1️⃣ Recibir IDs seleccionados desde Android
$ids = $_POST['ids'] ?? '';

if (empty($ids)) {
    echo "NO_IDS";
    exit;
}

// Seguridad: permitir solo números y comas
$ids = preg_replace('/[^0-9,]/', '', $ids);

if ($ids === '') {
    echo "NO_IDS";
    exit;
}

// 2️⃣ Obtener los inventarios seleccionados
$resInv = mysqli_query($conexion, "
    SELECT i.id, i.fecha_hora, u.usuario
    FROM inventarios i
    JOIN usuarios u ON i.usuario_id = u.id
    WHERE i.id IN ($ids)
    ORDER BY i.fecha_hora DESC
");

if (!$resInv || mysqli_num_rows($resInv) < 1) {
    echo "No hay inventarios válidos para analizar.";
    exit;
}

// 3️⃣ Construir texto de inventarios
$textoInventarios = "";
while ($inv = mysqli_fetch_assoc($resInv)) {
    $textoInventarios .= "Inventario de {$inv['usuario']} ({$inv['fecha_hora']}):\n";

    $resProd = mysqli_query($conexion, "
        SELECT nombre, cantidad 
        FROM inventario_productos 
        WHERE inventario_id = {$inv['id']}
    ");

    if ($resProd && mysqli_num_rows($resProd) > 0) {
        while ($p = mysqli_fetch_assoc($resProd)) {
            $textoInventarios .= "- {$p['nombre']}: {$p['cantidad']}\n";
        }
    } else {
        $textoInventarios .= "- No hay productos registrados.\n";
    }

    $textoInventarios .= "\n";
}

// 4️⃣ PROMPT OPTIMIZADO: Más limpio y directo para evitar cortes
$prompt = "
Actúa como analista de stock. Genera un informe breve y MUY visual.
NO USES TABLAS DE SÍMBOLOS (| o -). 

Usa exactamente este formato:

📊 RESUMEN EJECUTIVO:
(Escribe una frase corta del estado general)

━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 CAMBIOS EN PRODUCTOS:
(Para cada producto con variación, usa este bloque:)
📦 *Nombre del Producto*
   • Antes: [Cant] | Ahora: [Cant]
   • Estado: [Emoji según estado]

━━━━━━━━━━━━━━━━━━━━━━━━━━
🚨 ACCIONES RECOMENDADAS:
• [Recomendación rápida 1]
• [Recomendación rápida 2]

INVENTARIOS A COMPARAR:
$textoInventarios
";

// 5️⃣ Llamada a LM Studio local
$url = "http://127.0.0.1:1234/v1/chat/completions";

$data = json_encode([
    "model" => "mistralai/ministral-8b-instruct",
    "messages" => [
        [
            "role" => "system",
            "content" => "Eres un analista experto en inventarios para tiendas en España."
        ],
        [
            "role" => "user",
            "content" => $prompt
        ]
    ],
    "max_tokens" => 1000,
    "temperature" => 0.3
]);

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER => ["Content-Type: application/json"],
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $data,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 90 // más tiempo por IA local
]);

$response = curl_exec($ch);

if ($response === false) {
    echo "Error al conectar con la IA local: " . curl_error($ch);
    curl_close($ch);
    exit;
}
curl_close($ch);

$result = json_decode($response, true);

// Obtener el contenido del chat
if (isset($result['choices'][0]['message']['content'])) {
    echo $result['choices'][0]['message']['content'];
} else {
    echo "No se pudo generar el análisis. Respuesta del servidor: " . $response;
}
?>
