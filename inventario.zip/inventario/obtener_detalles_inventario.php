<?php
include 'conexion.php';

$inventario_id = $_POST['inventario_id'] ?? '';

if ($inventario_id === '') {
    echo "ID_VACIO";
    exit;
}

// Consultamos los productos de ese inventario específico
$res = mysqli_query($conexion, "SELECT nombre, cantidad FROM inventario_productos WHERE inventario_id = '$inventario_id'");

$salida = [];
while ($row = mysqli_fetch_assoc($res)) {
    $salida[] = $row['nombre'] . ": " . $row['cantidad'];
}

// Devolvemos la lista separada por saltos de línea para que sea fácil de leer
echo implode("\n", $salida);
?>