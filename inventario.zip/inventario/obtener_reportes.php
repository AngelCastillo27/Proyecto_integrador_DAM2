<?php
include 'conexion.php';

$usuario = $_POST['usuario'] ?? '';
$rol = $_POST['rol'] ?? ''; // Recibimos el rol desde Android

// 


// Si es ADMIN, ve todo. Si es OPERARIO, solo lo suyo.
if ($rol === 'ADMIN') {
    $query = "SELECT i.id, u.usuario, i.turno, i.fecha_hora 
              FROM inventarios i 
              JOIN usuarios u ON i.usuario_id = u.id 
              ORDER BY i.fecha_hora DESC";
} else {
    $query = "SELECT i.id, u.usuario, i.turno, i.fecha_hora 
              FROM inventarios i 
              JOIN usuarios u ON i.usuario_id = u.id 
              WHERE u.usuario = '$usuario' 
              ORDER BY i.fecha_hora DESC";
}

$res = mysqli_query($conexion, $query);
$salida = [];

while($row = mysqli_fetch_assoc($res)) {
    // Formato: id|usuario|turno|fecha
    $salida[] = $row['id'] . "|" . $row['usuario'] . "|" . $row['turno'] . "|" . $row['fecha_hora'];
}

echo implode(";", $salida);
?>