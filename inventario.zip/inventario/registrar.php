<?php
include "conexion.php";

$usuario   = $_POST['usuario'];
$password  = $_POST['password'];
$nombres   = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$rol       = $_POST['rol'];

// 1. Verificar si el usuario ya existe
$consulta = $conexion->prepare("SELECT id FROM usuarios WHERE usuario = ?");
$consulta->bind_param("s", $usuario);
$consulta->execute();
$consulta->store_result();

if ($consulta->num_rows > 0) {
    echo "ERROR_USUARIO_EXISTE";
    exit;
}

// 2. Insertar si NO existe
$insertar = $conexion->prepare(
    "INSERT INTO usuarios (usuario, password, nombres, apellidos, rol)
     VALUES (?, ?, ?, ?, ?)"
);
$insertar->bind_param("sssss", $usuario, $password, $nombres, $apellidos, $rol);

if ($insertar->execute()) {
    echo "USUARIO_REGISTRADO";
} else {
    echo "ERROR_REGISTRO";
}
?>
