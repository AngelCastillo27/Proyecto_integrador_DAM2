<?php
include 'conexion.php';

$usuario = $_POST['usuario'] ?? '';
$departamento = $_POST['departamento'] ?? '';

// 1. Obtener ID usuario
$res = mysqli_query($conexion, "SELECT id FROM usuarios WHERE usuario='$usuario'");
$usuario_id = mysqli_fetch_assoc($res)['id'];

// 2. Obtener último inventario abierto
$res = mysqli_query($conexion, "SELECT id FROM inventarios WHERE usuario_id='$usuario_id' AND estado='abierto' ORDER BY id DESC LIMIT 1");

$inventario_id = 0;
if (mysqli_num_rows($res) > 0) {
    $inventario_id = mysqli_fetch_assoc($res)['id'];
}

// 3. CONSULTA MÁGICA: Trae los maestros y los junta con lo que ya hay guardado
$sql = "SELECT m.nombre, IFNULL(p.cantidad, 0) as cantidad, 1 as es_estatico
        FROM productos_maestros m
        LEFT JOIN inventario_productos p ON m.nombre = p.nombre 
             AND p.inventario_id = '$inventario_id' 
             AND p.departamento = '$departamento'
        WHERE m.departamento = '$departamento'
        
        UNION
        
        SELECT nombre, cantidad, 0 as es_estatico
        FROM inventario_productos
        WHERE inventario_id = '$inventario_id' 
          AND departamento = '$departamento'
          AND nombre NOT IN (SELECT nombre FROM productos_maestros WHERE departamento = '$departamento')";

$res = mysqli_query($conexion, $sql);
$salida = [];
while ($row = mysqli_fetch_assoc($res)) {
    // Formato: nombre:cantidad:es_estatico
    $salida[] = $row['nombre'] . ":" . $row['cantidad'] . ":" . $row['es_estatico'];
}

echo "OK|" . implode(";", $salida);
?>