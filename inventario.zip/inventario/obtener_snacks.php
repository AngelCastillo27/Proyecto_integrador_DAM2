<?php
include "conexion.php";

$usuario = $_GET['usuario'] ?? '';

if ($usuario === '') {
    echo "DATOS_INCOMPLETOS";
    exit;
}

$stmt = $conexion->prepare("SELECT id FROM usuarios WHERE usuario = ?");
$stmt->bind_param("s", $usuario);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo "USUARIO_NO_EXISTE";
    exit;
}

$fila = $res->fetch_assoc();
$usuario_id = $fila['id'];

$stmt = $conexion->prepare(
    "SELECT nombre, cantidad 
     FROM productos 
     WHERE usuario_id = ? AND departamento = 'SNACKS'"
);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$res = $stmt->get_result();

$snacks = [];

while ($row = $res->fetch_assoc()) {
    $snacks[] = $row;
}

echo json_encode($snacks);
