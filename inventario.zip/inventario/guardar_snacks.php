<?php
include "conexion.php";

$usuario   = $_POST['usuario']   ?? '';
$productos = $_POST['productos'] ?? '';

if ($usuario === '' || $productos === '') {
    echo "DATOS_INCOMPLETOS";
    exit;
}

$stmt = $conexion->prepare("SELECT id FROM usuarios WHERE usuario = ?");
$stmt->bind_param("s", $usuario);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo "USUARIO_NO_EXISTE";
    exit;
}

$fila = $res->fetch_assoc();
$usuario_id = $fila['id'];

// 🔥 BORRAR SOLO CUANDO SE GUARDA
$stmt = $conexion->prepare(
    "DELETE FROM productos 
     WHERE usuario_id = ? AND departamento = 'SNACKS'"
);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();

$stmt = $conexion->prepare(
    "INSERT INTO productos (usuario_id, departamento, nombre, cantidad)
     VALUES (?, 'SNACKS', ?, ?)"
);

$lista = explode(",", $productos);

foreach ($lista as $p) {

    if (strpos($p, ":") === false) continue;

    list($nombre, $cantidad) = explode(":", $p, 2);

    $nombre = trim($nombre);
    $cantidad = (int) trim($cantidad);

    if ($nombre === '' || $cantidad <= 0) continue;

    $stmt->bind_param("isi", $usuario_id, $nombre, $cantidad);
    $stmt->execute();
}

echo "SNACKS_GUARDADOS";
