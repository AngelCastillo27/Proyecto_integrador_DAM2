<?php
include "conexion.php";

$usuario = $_POST['usuario'] ?? '';

if ($usuario === '') {
    echo "DATOS_INCOMPLETOS";
    exit;
}

$stmt = $conexion->prepare("SELECT id FROM usuarios WHERE usuario = ?");
$stmt->bind_param("s", $usuario);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
    echo "USUARIO_NO_EXISTE";
    exit;
}

$fila = $res->fetch_assoc();
$usuario_id = $fila['id'];

$stmt = $conexion->prepare(
    "SELECT nombre, cantidad FROM productos
     WHERE usuario_id = ? AND departamento = 'SNACKS'
     ORDER BY id DESC"
);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$res = $stmt->get_result();

$salida = [];

while ($row = $res->fetch_assoc()) {
    $salida[] = $row['nombre'] . ":" . $row['cantidad'];
}

echo "OK|" . implode(";", $salida);
