<?php
include 'conexion.php';

// Recibimos los IDs seleccionados desde Android (ej: "5,8,12")
$ids_seleccionadas = $_POST['ids'] ?? '';

if (empty($ids_seleccionadas)) {
    echo "NO_IDS";
    exit;
}

// Seguridad básica: solo números y comas
$ids_seleccionadas = preg_replace('/[^0-9,]/', '', $ids_seleccionadas);

// Obtenemos solo los inventarios seleccionados
$query = "
    SELECT i.id, i.fecha_hora, u.usuario
    FROM inventarios i
    JOIN usuarios u ON i.usuario_id = u.id
    WHERE i.id IN ($ids_seleccionadas)
    ORDER BY i.fecha_hora DESC
";

$resInv = mysqli_query($conexion, $query);

$datosParaIA = [];

while ($inv = mysqli_fetch_assoc($resInv)) {
    $id = $inv['id'];
    $detalles = [];

    $resProd = mysqli_query(
        $conexion,
        "SELECT nombre, cantidad FROM inventario_productos WHERE inventario_id = '$id'"
    );

    while ($p = mysqli_fetch_assoc($resProd)) {
        $detalles[] = $p['nombre'] . ": " . $p['cantidad'];
    }

    $datosParaIA[] =
        "Inventario de " . $inv['usuario'] .
        " el " . $inv['fecha_hora'] .
        ": [" . implode(", ", $detalles) . "]";
}

// Enviamos SOLO los inventarios seleccionados a la IA
echo implode("\n\n", $datosParaIA);
?>
