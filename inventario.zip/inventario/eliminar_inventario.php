<?php
include 'conexion.php';

$inventario_id = $_POST['inventario_id'] ?? '';

if ($inventario_id === '') {
    echo "ID_VACIO";
    exit;
}

mysqli_query(
    $conexion,
    "DELETE FROM inventario_productos WHERE inventario_id='$inventario_id'"
);

mysqli_query(
    $conexion,
    "DELETE FROM inventarios WHERE id='$inventario_id'"
);

echo "OK";
